﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!User.Identity.IsAuthenticated)
        {
            Response.Redirect("prijava.aspx");
        }
        this.korisnicko.Text = User.Identity.Name;
    }

    protected void ButtonSendNewThread_Click(object sender, EventArgs e)
    {
        string connString = ConfigurationManager.ConnectionStrings["konekcijaBaze"].ConnectionString;
        SqlConnection connection = new SqlConnection(connString);

        connection.Open();

        //za ubacivnje novih tema u bazu podataka
        SqlCommand ubaciTemu = new SqlCommand("INSERT INTO teme (naslov, uvod, id_korisnik) " +
                                              "VALUES (@naslov, @uvod, (SELECT id FROM korisnici WHERE korisnickoIme=@korisnickoIme)) " +
                                              "SELECT SCOPE_IDENTITY()", connection);
        ubaciTemu.Parameters.AddWithValue("@naslov", this.naslovTeme.Text);
        ubaciTemu.Parameters.AddWithValue("@uvod", this.uvodTeme.Text);
        ubaciTemu.Parameters.AddWithValue("@korisnickoIme", User.Identity.Name.Trim());
        //https://docs.microsoft.com/en-us/aspnet/web-pages/overview/getting-started/introducing-aspnet-web-pages-2/entering-data

        //pretvarenje ID u string
        string idteme = ubaciTemu.ExecuteScalar().ToString();
        //https://stackoverflow.com/questions/16647140/return-value-using-string-result-command-executescalar-error-occurs-when-resul/16647312

        connection.Close();
        //usmjeravelje na ubacenu temu 
        Response.Redirect("pregledtema.aspx?idteme=".Insert(24, value: idteme));

        //https://msdn.microsoft.com/en-us/library/system.string.insert(v=vs.110).aspx

        connection.Close();
    }

}