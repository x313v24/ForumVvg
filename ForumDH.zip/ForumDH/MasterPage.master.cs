﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls; 
using System.Configuration; // dohvaćanje podataka iz konfiguracijske datoteke

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.vrijeme.Text = DateTime.Now.ToString(); 
        korisnicko.Text = HttpContext.Current.User.Identity.Name;
    }
}
