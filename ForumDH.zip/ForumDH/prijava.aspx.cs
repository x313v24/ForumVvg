﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (User.Identity.IsAuthenticated)
        {
            //ako je korisnik prijavljen, redirect na početnu
            Response.Redirect("~/pocetna.aspx");
        }
    }

    protected void PrijaviKorisnika(object sender, EventArgs e)
    {
        //provjeri korisnika i lozinku
        string connString = ConfigurationManager.ConnectionStrings["konekcijaBaze"].ConnectionString;
        SqlConnection connection = new SqlConnection(connString);
        SqlCommand prijava = new SqlCommand("SELECT * FROM korisnici " +
                                            "WHERE korisnickoIme = @korisnickoIme " +
                                            "AND lozinka = @lozinka", connection);

        prijava.Parameters.AddWithValue("@korisnickoIme", this.prikorisnicko.Text);
        prijava.Parameters.AddWithValue("@lozinka", this.prilozinka.Text);

            connection.Open();
            SqlDataReader ucitajPodatke = prijava.ExecuteReader();
            if (ucitajPodatke.HasRows)
            {
                FormsAuthentication.RedirectFromLoginPage(prikorisnicko.Text, true);
                Response.Redirect("~/prijava.aspx");
            }
            else
            {
                Response.Write("Prijava nije uspjela");
            }
        }
    }
