﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //ako nema queryString-a
        if (Request.QueryString["idteme"] == null)
        {
            Response.Redirect("pocetna.aspx");
        }
        this.korisnickoIme.Text = User.Identity.Name;
    }

    protected void ButtonReply_Click(object sender, EventArgs e)
    {
        //konekcija, query za odgovore
        string connString = ConfigurationManager.ConnectionStrings["konekcijaBaze"].ConnectionString;
        SqlConnection connection = new SqlConnection(connString);
       //insertanje unesene poruke u bazu podataka
            connection.Open();
            SqlCommand ubaciporuku = new SqlCommand("INSERT INTO postovi (poruka, id_tema, id_korisnik)" +
                                                    "VALUES (@poruka , @temaID, (SELECT Id FROM korisnici " +
                                                    "WHERE korisnickoIme=@korisnickoIme))", connection);

            ubaciporuku.Parameters.AddWithValue("@temaID", Request.QueryString["idteme"]); 
            ubaciporuku.Parameters.AddWithValue("@korisnickoIme", User.Identity.Name.Trim()); 
            ubaciporuku.Parameters.AddWithValue("@poruka", this.TextBoxOdgovori.Text); 
            ubaciporuku.ExecuteNonQuery();
            connection.Close();
            Response.Redirect(Request.Url.ToString(), true);

            //zatvarnaje konekcije
            connection.Close();
        }

    }


