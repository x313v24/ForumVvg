﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        //ako je korisnik već ulogiran 
        if (User.Identity.IsAuthenticated)
        {
            Response.Redirect("pocetna.aspx");
        }
    }


    protected void RegistrirajKorisnika (object sender, EventArgs e)
    {
        //web.config
        string connectionString = ConfigurationManager.ConnectionStrings["konekcijaBaze"].ConnectionString;
        //nova konenkija na bazu
        SqlConnection insertUser = new SqlConnection(connectionString);
        //ubacivanje korisnika u bazu
        SqlCommand ubaci = new SqlCommand("INSERT INTO korisnici (ime, prezime, korisnickoIme, lozinka, email) " +
                                            "VALUES (@ime,@prezime,@korisnickoIme,@lozinka,@email)", insertUser);
        //parametri
        ubaci.Parameters.AddWithValue("@ime", this.txtime.Text);
        ubaci.Parameters.AddWithValue("@prezime", this.txtprezime.Text);
        ubaci.Parameters.AddWithValue("@korisnickoIme", this.txtkorisnicko.Text);
        ubaci.Parameters.AddWithValue("@lozinka", this.txtlozinka.Text);
        ubaci.Parameters.AddWithValue("@email", this.txtemail.Text);

        //otvara konkciju i izvršava naredbu 
        insertUser.Open();
        ubaci.ExecuteNonQuery();
            
        //zatvaranje
        insertUser.Close();

        Response.Redirect("~/prijava.aspx");
    }
}
